/* -*- Mode:c++ -*- */

/*
 * Copyright (c) 2008 Regents of the SIGNET lab, University of Padova.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the University of Padova (SIGNET lab) nor the 
 *    names of its contributors may be used to endorse or promote products 
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef POSITION_CLMSG_H
#define POSITION_CLMSG_H

#include <clmessage.h>

#define CLMSG_POSITION_VERBOSITY 2	// verbosity of this message


extern ClMessage_t CLMSG_POSITION_GET_DIST;

 
class ClMsgPositionGetDist : public ClMessage
{
public:
  ClMsgPositionGetDist(nsaddr_t i, nsaddr_t j);
  virtual ~ClMsgPositionGetDist() {}
  virtual ClMessage* copy();	// copy the message
  virtual void returnDist(double d);
  virtual double getDist()  {return dist;}
  virtual nsaddr_t getId1() {return id1;}
  virtual nsaddr_t getId2() {return id2;}
  bool isValid() {return valid;}

 protected:
  double dist;
  bool valid;
  nsaddr_t id1;
  nsaddr_t id2;
};






#endif  // POSITION_CLMSG_H
