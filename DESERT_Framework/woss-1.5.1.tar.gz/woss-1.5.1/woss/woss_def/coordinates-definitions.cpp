/* WOSS - World Ocean Simulation System -
 * 
 * Copyright (C) 2009 Regents of Patavina Technologies 
 *
 * Author: Federico Guerra - federico@guerra-tlc.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */ 

/*
 * This software has been developed by Patavina Technologies, s.r.l., 
 * in collaboration with the NATO Undersea Research Centre 
 * (http://www.nurc.nato.int; E-mail: pao@nurc.nato.int), 
 * whose support is gratefully acknowledged.
 */


/**
 * @file   coordinates-definitions.cpp
 * @author Federico Guerra
 * 
 * \brief Provides the implementation of the woss::Coord and woss::CoordZ classes
 *
 * Provides the implementation of the woss::Coord and woss::CoordZ classes
 */


#include <cmath>
#include <assert.h>


#include "coordinates-definitions.h"


using namespace woss;


double Coord::earth_radius = 6371000.0;


Coord::Coord( double lat, double lon ) 
: latitude(lat),
  longitude(lon),
  marsden_square(COORD_NOT_SET_VALUE),
  marsden_one_degree(COORD_NOT_SET_VALUE)
{
  updateMarsdenCoord();
}


Coord::Coord( const Coord& coords ) 
{
  latitude = coords.latitude;
  longitude = coords.longitude;
  updateMarsdenCoord();
}


void Coord::updateMarsdenCoord() {
  if( !isValid() ) {
    marsden_one_degree = COORD_NOT_SET_VALUE;
    marsden_square = COORD_NOT_SET_VALUE;
    return;
  }

  double lat = latitude;
  double lon = longitude;

  marsden_one_degree =(int)( (floor(std::abs(lat)) - floor(std::abs(lat)/10.0)*10.0)*10.0 + (floor(std::abs(lon)) - floor(std::abs(lon)/10.0)*10.0));

  if (( lat >= 0.0) && (lat < 80.0) ) {
    if (lon > 0.0) lon -=360.0;
    lon = std::abs(lon); 
    int quoz_lat = (int)floor(lat / 10.0);
    int quoz_long = (int)ceil(lon / 10.0);
    marsden_square = quoz_lat * 36 + quoz_long;
  }
  else if (lat >= 80.0) {
    if (lon > 0.0) lon -=360.0;
    lon = std::abs(lon); 
    int quoz_long = (int)ceil(lon / 10.0);
    marsden_square = 900 + quoz_long;
  }
  else {
    if (lon > 0.0) lon -=360.0;
    lon = std::abs(lon); 
    lat = std::abs(lat);
    int quoz_lat = (int)floor(lat / 10.0);
    int quoz_long = (int)floor(lon / 10.0);
    marsden_square = 300 + quoz_lat * 36 + quoz_long;
  }
} 


double Coord::getInitialBearing( const Coord& destination ) const {
  assert( static_cast<Coord>(destination).isValid() );

  double lat1 =  latitude * M_PI / 180.0; 
  double lat2 =  destination.latitude * M_PI / 180.0;
  double dLon =  (destination.longitude - longitude) * M_PI / 180.0;

  double y = sin(dLon) * cos(lat2);
  double x = cos(lat1)* sin(lat2) - sin(lat1)* cos(lat2) * cos(dLon);

  return( atan2(y, x) );
}


double Coord::getGreatCircleDistance( const Coord& destination, double depth ) const {
  assert( static_cast<Coord>(destination).isValid() );

  double dLat =  (destination.latitude - latitude) * M_PI / 180.0;
  double dLon =  (destination.longitude - longitude) * M_PI / 180.0;
  double lat1 =  latitude * M_PI / 180.0;
  double lat2 =  destination.latitude * M_PI / 180.0;

  double a = sin(dLat/2.0) * sin(dLat/2.0) +
          cos(lat1) * cos(lat2) * 
          sin(dLon/2.0) * sin(dLon/2.0);

  double c = 2.0 * atan2(sqrt(a), sqrt(1.0-a));

  return((earth_radius - depth) * c);
}


const Coord Coord::getCoordFromBearing( const Coord& destination, double bearing, double distance, double depth ) {
  assert( static_cast<Coord>(destination).isValid() );
 
  double lat1 = destination.latitude * M_PI / 180.0; 
  double lon1 = destination.longitude * M_PI / 180.0;
  double lat2 = asin( sin(lat1) * cos(distance/(earth_radius-depth)) 
              + cos(lat1) * sin(distance/(earth_radius-depth)) * cos(bearing) );
  double lon2 = lon1 + atan2(sin(bearing) * sin(distance/(earth_radius-depth)) * cos(lat1), 
                             cos(distance/(earth_radius-depth)) - sin(lat1) * sin(lat2));

  double ret_lat = lat2 * 180.0 / M_PI;
  double ret_long = lon2 * 180.0 / M_PI;
  if (ret_lat > 90.0) ret_lat -= 180.0;
  if (ret_long > 180.0) ret_long -= 360.0;
     
  return( Coord(ret_lat, ret_long) );
}


bool Coord::isValidUtmZoneChar( UtmZoneChar utm_zone_char )
{
  if ( ( (utm_zone_char >= 'C') && ( utm_zone_char <= 'X' ) && (utm_zone_char != 'I') 
        && (utm_zone_char != 'O') ) 
     || ( (utm_zone_char >= 'c') && ( utm_zone_char <= 'x' ) && (utm_zone_char != 'i') 
        && (utm_zone_char != 'o') )  ) 
    return true;
   
  return false;
}


const Coord Coord::getCoordFromUtmWgs84( double easting, double northing, double utm_zone_number, UtmZoneChar utm_zone_char)
{
  if ( !isValidUtmZoneChar(utm_zone_char) ) {
     ::std::cerr << "Coord::getCoordFromUtmWgs84() easting = " << easting << "; northing = " << northing
                 << "; utm zone = " << utm_zone_number << "; utm zone char = " << utm_zone_char 
                 << "; WARNING, invalid input parameters!!" << ::std::endl;
  }
  
  /*::std::cout << "Coord::getCoordFromUtmWgs84() easting = " << easting << "; northing = " << northing
              << "; utm zone = " << utm_zone_number << "; utm zone char = " << utm_zone_char 
              << "; zone int = " << (unsigned int) utm_zone_char << "; c = " << (unsigned int) 'c' 
              << "; m = " << (unsigned int) 'm' << "; C = " << (unsigned int) 'C' << "; M = " 
              << (unsigned int) 'M' << ::std::endl; */
  
  bool is_hemis_north = true;
  
  if (  ((utm_zone_char < 'M') && (utm_zone_char >= 'C')) 
     || ((utm_zone_char < 'm') && (utm_zone_char >= 'c')) ) {
    is_hemis_north = false;
  }
  
  // Equatorial radius
  double sa = 6378137.000000 ; 
  // Polar radius
  double sb = 6356752.314245 ;
  
  double e2 = ::std::pow( ( ::std::pow(sa, 2.0) - ::std::pow(sb, 2.0) ), 0.5 ) / sb;
  double e2square = ::std::pow( e2, 2.0);
  double c = ::std::pow( sa, 2.0 ) / sb;
  
  // Conventional easting (not referred to standard meridian)
  double X = easting - 500000.0;
  
  // Standard northing shift if the UTM zone is in the southern emispèhere
  double Y; 
  
  if ( is_hemis_north == false )
      Y = northing - 10000000.0;
  else
      Y = northing;
      
  // UTM zone
  double S   = ( ( utm_zone_number * 6.0 ) - 183.0 );
  double lat =  Y / ( 6366197.724 * 0.9996 ) ;
  
  double v   = ( c / ::std::pow( ( 1.0 + ( e2square * ::std::pow( ::std::cos(lat), 2.0 ) ) ), 0.5 ) ) * 0.9996;
  
  double a   = X / v ;
  
  double a1   = ::std::sin( 2.0 * lat ) ;
  double a2   = a1 * ::std::pow( ::std::cos(lat), 2.0);
  
  double j2   = lat + a1/2.0 ;
  double j4   = ( 3.0 * j2 + a2 ) / 4.0 ;
  double j6   = ( 5.0 * j4 + a2 * ::std::pow( ::std::cos(lat), 2.0 ) ) / 3.0;
  
  double alpha = 3.0/4.0 * e2square ;
  double beta  =  5.0/3.0 * ::std::pow( alpha, 2.0 );
  double gamma = 35.0/27.0 * ::std::pow( alpha, 3.0 );
  
  double Bm   = 0.9996 * c * ( lat - alpha * j2 + beta * j4 - gamma * j6 );
  double b    = ( Y - Bm ) / v ;
  double Epsi = e2square * ::std::pow( a, 2.0 ) / 2.0 * ::std::pow( ::std::cos(lat), 2.0 );
  double Epss = a * ( 1.0 - Epsi / 3.0 );
  double nab  = b * ( 1.0 - Epsi ) + lat;
  
  double Delt = ::std::atan( ::std::sinh(Epss) / ::std::cos(nab) );
  double TaO  = ::std::atan( ::std::cos(Delt) * ::std::tan(nab) );
  
  double longitude = Delt * 180.0 / M_PI + S;
  double latitude  = ( lat + ( 1.0 + e2square * ::std::pow( ::std::cos(lat), 2.0 ) - 3.0/2.0 * e2square * ::std::sin(lat) * ::std::cos(lat) * ( TaO - lat ) ) * ( TaO - lat ) ) * 180.0 / M_PI;
  
//     ::std::cout << "Coord::getCoordFromUtmWgs84() latitude = " << latitude 
//                 << "; longitude = " << longitude << ::std::endl;
              
  return Coord(latitude, longitude);
}


const Coord Coord::getCoordAlongGreatCircle( const Coord& start_coord, const Coord& end_coord, double distance, double depth ) {
  return Coord::getCoordFromBearing( start_coord, start_coord.getInitialBearing(end_coord), distance, depth ); 
} 


Coord& Coord::operator=( const Coord& coords ) {
  if (this == &coords) return *this;
  latitude = coords.latitude;
  longitude = coords.longitude;
  marsden_square = coords.marsden_square;
  marsden_one_degree = coords.marsden_one_degree;
  return *this;
}


Coord& woss::operator+=( Coord& left, const Coord& right ) {
  if( !( left.isValid() && right.isValid() ) ) {
    left.latitude = COORD_NOT_SET_VALUE;
    left.longitude = COORD_NOT_SET_VALUE;
  }
  left.latitude += right.latitude;
  left.longitude += right.longitude;
  return left;
}


Coord& woss::operator-=( Coord& left, const Coord& right ) {
  if( !( left.isValid() && right.isValid() ) ) {
    left.latitude = COORD_NOT_SET_VALUE;
    left.longitude = COORD_NOT_SET_VALUE;
  }
  left.latitude -= right.latitude;
  left.longitude -= right.longitude;
  return left;
}


CoordZ::CoordZ(double lat, double lon, double d) 
  : Coord(lat,lon),
    depth(d)
{

}


CoordZ::CoordZ(const Coord& coords, double d)
  :  Coord(coords),
     depth(d)
{

}


CoordZ::CoordZ(const CoordZ& coordz) 
: Coord(coordz),
  depth(coordz.depth)
{

}


double CoordZ::getCartX() const {
  return (earth_radius - depth) * sin( (90.0 - latitude) * M_PI / 180.0 ) * cos( longitude * M_PI / 180.0 );
}


double CoordZ::getCartY() const {
  return (earth_radius - depth) * sin( (90.0 - latitude) * M_PI / 180.0 ) * sin( longitude * M_PI / 180.0 );
}


double CoordZ::getCartZ() const {
  return (earth_radius - depth) * cos( (90.0 - latitude) * M_PI / 180.0 );
}
    
    
double CoordZ::getCartDistance( const CoordZ& coords ) const {   
  return sqrt( pow( (coords.getCartX() - getCartX()) ,2.0) + pow( (coords.getCartY() - getCartY()) ,2.0) 
             + pow( (coords.getCartZ() - getCartZ()) ,2.0) );
}


double CoordZ::getCartRelAzimuth( const CoordZ& coords ) const {
  assert( coords.isValid() );   
  return( atan2( (coords.getCartY() - getCartY()) , (coords.getCartX() - getCartX()) )  );
}


double CoordZ::getCartRelZenith( const CoordZ& coords ) const {
  assert( coords.isValid() );
  return acos( (coords.getCartZ() - getCartZ()) / getCartDistance(coords) );
}


const CoordZ CoordZ::getCoordZAlongGreatCircle( const CoordZ& start, const CoordZ& end, double distance ) {
  double start_depth = start.getDepth();
  double end_depth = end.getDepth();
  double total_distance = start.getGreatCircleDistance( end, start_depth );
  
  if ( total_distance == 0.0 && start_depth != end_depth ) {
    total_distance = ::std::abs(end_depth - start_depth);  
    assert( distance < total_distance );
    
    return( CoordZ( static_cast<Coord>(start), distance ) );
  }
 
  double delta_depth = end_depth - start_depth;
  double curr_depth = start_depth + distance / total_distance * delta_depth;
                
  return( CoordZ( Coord::getCoordAlongGreatCircle( start, end, distance , start_depth ) , curr_depth ) );
}


const CoordZ CoordZ::getCoordZAlongCartLine( const CoordZ& start, const CoordZ& end, double distance ) { 
  double Xsorg_ = start.getCartX();
  double Ysorg_ = start.getCartY();
  double Zsorg_ = start.getCartZ();
  
//  double Xdest_ = end.getCartX();
//  double Ydest_ = end.getCartY();
//  double Zdest_ = end.getCartZ();
   
  double azimut = start.getCartRelAzimuth( end );
  double polar = start.getCartRelZenith( end );

  double x_fin = Xsorg_ + distance * cos(azimut) * sin(polar);
  double y_fin = Ysorg_ + distance * sin(azimut) * sin(polar);
  double z_fin = Zsorg_ + distance * cos(polar);
  
  ::std::cout << ::std::endl;
//   ::std::cout << "x_fin = " << x_fin << "; Xdest_ = " << Xdest_ << "; diff = " << (x_fin - Xdest_) << ::std::endl;
//   ::std::cout << "y_fin = " << y_fin << "; Ydest_ = " << Ydest_ << "; diff = " << (y_fin - Ydest_) << ::std::endl;
//   ::std::cout << "z_fin = " << z_fin << "; Zdest_ = " << Zdest_ << "; diff = " << (z_fin - Zdest_) << ::std::endl;
  
  ::std::cout << ::std::endl;
//   ::std::cout << "x_fin = " << x_fin << "; Xsorg_ = " << Xsorg_ << "; diff = " << (x_fin - Xsorg_) << ::std::endl;
//   ::std::cout << "y_fin = " << y_fin << "; Ysorg_ = " << Ysorg_ << "; diff = " << (y_fin - Ysorg_) << ::std::endl;
//   ::std::cout << "z_fin = " << z_fin << "; Zsorg_ = " << Zsorg_ << "; diff = " << (z_fin - Zsorg_) << ::std::endl;
  
  ::std::cout << ::std::endl;
//   ::std::cout << "Xdest_ = " << Xdest_ << "; Xsorg_ = " << Xsorg_ << "; diff = " << (Xdest_ - Xsorg_) << ::std::endl;
//   ::std::cout << "Ydest_ = " << Ydest_ << "; Ysorg_ = " << Ysorg_ << "; diff = " << (Ydest_ - Ysorg_) << ::std::endl;
//   ::std::cout << "Zdest_ = " << Zdest_ << "; Zsorg_ = " << Zsorg_ << "; diff = " << (Zdest_ - Zsorg_) << ::std::endl;
  
  double lat = 90.0 - 180.0 / M_PI * acos( z_fin / sqrt( pow(x_fin,2.0) + pow(y_fin,2.0) + pow(z_fin,2.0) ) );
  double lon = 180.0 / M_PI * atan2( y_fin, x_fin );
  double depth = sqrt( pow(x_fin,2.0) + pow(y_fin,2.0) + pow(z_fin,2.0) ) - earth_radius;
  
//   ::std::cout << "lat = " << lat << ::std::endl;
//   ::std::cout << "long = " << lon << ::std::endl;
//   ::std::cout << "depth = " << depth << ::std::endl;
     
  return CoordZ( lat, lon, ::std::abs(depth) );
}
   
    
CoordZ& CoordZ::operator=( const CoordZ& coordz ) {
  if (this == &coordz) return *this;
  latitude = coordz.latitude;
  longitude = coordz.longitude;
  marsden_square = coordz.marsden_square;
  marsden_one_degree = coordz.marsden_one_degree;
  depth = coordz.depth;
  return *this;
}


CoordZ& woss::operator+=( CoordZ& left, const CoordZ& right ) {
  if( !( left.isValid() && right.isValid() ) ) {
    left.latitude = COORD_NOT_SET_VALUE;
    left.longitude = COORD_NOT_SET_VALUE;
    left.depth = COORD_NOT_SET_VALUE;
  }
  left.latitude += right.latitude;
  left.longitude += right.longitude;
  left.depth += right.depth;
  return left;
}
  

CoordZ& woss::operator-=( CoordZ& left, const CoordZ& right ) {
  if( !( left.isValid() && right.isValid() ) ) {
    left.latitude = COORD_NOT_SET_VALUE;
    left.longitude = COORD_NOT_SET_VALUE;
    left.depth = COORD_NOT_SET_VALUE;
  }
  left.latitude -= right.latitude;
  left.longitude -= right.longitude;
  left.depth -= right.depth;
  return left;
}


const CoordZ CoordZ::getCoordZFromCartesianCoords( double x, double y, double z ) {
  double lat = 90.0 - 180.0 / M_PI * acos( z / sqrt( pow(x,2.0) + pow(y,2.0) + pow(z,2.0) ) );
  double lon = 180.0 / M_PI * atan2( y, x );
  double depth = sqrt( pow(x,2.0) + pow(y,2.0) + pow(z,2.0) ) - earth_radius;
  
//   ::std::cout << "lat = " << lat << ::std::endl;
//   ::std::cout << "long = " << lon << ::std::endl;
//   ::std::cout << "depth = " << depth << ::std::endl;
     
  return CoordZ( lat, lon, ::std::abs(depth) );
}


const CoordZ CoordZ::getCoordZFromSphericalCoords( double rho, double theta, double phi ) {
  // we want to be underwater!
  assert(rho <= earth_radius);
	
  return CoordZ( (90.0 - theta), phi, ::std::abs(earth_radius - rho) );
}
