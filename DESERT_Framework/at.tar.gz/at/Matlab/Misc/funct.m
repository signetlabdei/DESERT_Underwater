function f = funct( x )
% defines function for root finder


f = x*x + 2;
x,f
end