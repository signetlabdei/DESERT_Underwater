% noise runs

cd Halfspace
runtests

cd ../Pekeris
runtests

cd ../ATOC
runtests

cd ..
