% Run test for head wave problem

sparc head
fieldsco head.grn
plotmovie head.shd.mat
