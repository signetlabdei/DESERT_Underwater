% Munk profile test cases
% mbp

bellhopM( 'arcticB' )
plotshd( 'arcticB.shd.mat', 2, 2, 1 )
caxisrev( [ 50 100 ] )

bellhopM( 'arcticB_gb' )
plotshd( 'arcticB_gb.shd.mat', 2, 2, 2 )
caxisrev( [ 50 100 ] )

kraken( 'arcticK' )
plotshd( 'arcticK.shd.mat', 2, 2, 3 )
caxisrev( [ 50 100 ] )

scooterM( 'arcticS' )
plotshd( 'arcticS.shd.mat', 2, 2, 4 )
caxisrev( [ 50 100 ] )