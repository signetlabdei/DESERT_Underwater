% run the provinces3D test cases
% mbp, September 2024
global units
units = 'km';

%%
makebdry             % make the bathymetry

%%
figure
plotbdry3d provinces.bty

%%
bellhop3d provinces     % run BELLHOP3D on the provinces3d test case

% polar plot of the TL
figure
plotshdpol( 'provinces.shd', 0, 0, 50 )
axis( [ -10 10 -10 10 ] )
caxisrev( [ 60 80 ] )
