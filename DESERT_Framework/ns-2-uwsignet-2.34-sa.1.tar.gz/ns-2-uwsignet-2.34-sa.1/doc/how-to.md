# ns-2.34 Core Architecture (DESERT Underwater Edition)

This document provides a comprehensive overview of the stripped-down `ns-2.34` codebase that serves as the event-driven simulation engine for the DESERT Underwater framework.

In this customized version, all obsolete modules have been purged to create a lightweight discrete-event scheduler focused on providing the base C++/OTcl object linkage needed by DESERT and nsmiracle.

---

## 1. Directory Tree & Folder Structure

Below is the structure of the directories:

- **`bin/`**: Contains utility scripts used during the build process, such as `tcl-expand.tcl` (used to package the OTcl standard library into a single C++ source file) and `string2c.tcl`.
- **`common/`**: Contains the core C++ simulation engine, event schedulers, packet definitions, nodes, finite state machines (FSM), and timers.
- **`conf/`**: Autoconf configuration files (`.in` templates) and environment detection scripts used by `./configure`.
- **`lib/`**: Contains additional C++ and Tcl linkage libraries if needed.
- **`link/`**: Link-layer models (`delay.cc`, `delay.h`).
- **`mac/`**: Core MAC layer components (`mac.cc`, `ll.cc`, `arp.cc`, `phy.cc`, `channel.cc`). Note that DESERT overrides many of these with nsmiracle PHY/MAC implementations.
- **`queue/`**: Basic queueing models.
- **`tcl/`**: The OTcl frontend scripts that initialize the simulator.
- **`tcl/lib/`**: Contains the critical `ns-*.tcl` scripts (`ns-lib.tcl`, `ns-node.tcl`, `ns-packet.tcl`, etc.) that act as the OTcl API.
- **`tools/`**: Helper utilities like Random Number Generators (`random.cc`, `rng.cc`, `ranvar.cc`), integrators, and queue monitors.
- **`trace/`**: Base tracing and logging logic (`trace.cc`, `basetrace.cc`), utilized when writing `.out` trace files.

---

## 2. Main Components

The simulator architecture operates using a **Split Object Model**, meaning virtually every major component exists in C++ for performance, but has a mirrored OTcl object for configuration and topology setup.

### A. The Event Scheduler (`common/scheduler.cc`)
The Scheduler is the discrete-event engine driving the simulation. It maintains a queue of `Event` objects sorted by their execution time.
- **`CalendarScheduler`**: The default scheduler, heavily optimized for a large number of events using a calendar queue data structure.
- **`RealTimeScheduler`**: Synchronizes the simulation clock with the wall-clock time (`clock_gettime(CLOCK_MONOTONIC_RAW)`), useful when the simulator is interfacing with real hardware or live networks.
- **`SplayScheduler`**: An alternative splay-tree based scheduler.

### B. Packets (`common/packet.h`, `common/packet.cc`)
The fundamental unit of data exchange. Packets in `ns-2` are monolithic; memory is allocated for all registered headers at once to avoid dynamic allocation overhead during simulation. 
- In this optimized build, the packet headers have been culled. Only essential headers (`Common`, `Flags`, `IP`, `ARP`, `Mac`, `LL`) are registered in `common/packet.h` and `tcl/lib/ns-packet.tcl`, significantly reducing memory consumption per packet.

### C. Nodes and Routing (`common/node.cc`, `tcl/lib/ns-node.tcl`)
The `Node` is the base network element. Originally, nodes possessed complex `Classifier` and `Agent` trees to handle IP routing. In the DESERT paradigm, the node is reduced to a blank slate, as `nsmiracle` and DESERT handle the complex multi-layer networking stack and cross-layer messaging dynamically.

### D. TclCL (Tcl/C++ Linkage)
TclCL provides the glue between C++ and OTcl. When a script calls `new Simulator`, TclCL catches the call, creates the corresponding C++ `Simulator` object, and establishes a binding. C++ objects can be manipulated from OTcl using the `cmd()` function, which acts as the C++ entry point for OTcl method calls.

---

## 3. How to Compile

Because this `ns-2.34` distribution is specifically tuned for DESERT Underwater, it relies on specific versions of TCL, OTCL, and TCLCL, and should ideally be compiled using DESERT's automated installer.

### Automated Compilation (Recommended)
1. Drop the `ns-2.34.tar.gz` archive into the DESERT installer's `DESERT_Framework/` directory.
2. Run the standard DESERT installation script:
   ```bash
   ./install.sh --target LOCAL --inst_mode development
   ```
   The script will unpack `ns-2.34`, apply any necessary environment variables, and compile it automatically alongside `nsmiracle` and `woss`.

### Manual Compilation
If you need to compile the simulator in isolation for testing or debugging:

1. **Extract and Configure:**
   ```bash
   tar -xzf ns-2.34.tar.gz
   cd ns-2.34
   ./configure
   ```
   *(Note: If building outside of the DESERT ecosystem, you may need to pass explicit arguments to `./configure` pointing to your local `tcl8.5`, `otcl`, and `tclcl` paths).*

2. **Compile:**
   ```bash
   make -j$(nproc)
   ```
   The `Makefile.in` has been manually scrubbed to remove X11 targets, emulation bindings (`nse`), GUI targets (`nstk`), and obsolete modules, so the build should be exceptionally fast.

3. **Verify:**
   The output binary `ns` will be placed in the root directory. You can test it by running an OTcl script:
   ```bash
   ./ns test_script.tcl
   ```
