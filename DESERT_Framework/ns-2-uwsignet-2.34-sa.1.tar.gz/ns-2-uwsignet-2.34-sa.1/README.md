⚠️ Note ⚠️
------------------
This fork contains ns-2 Network Simulation dependencies required by the [DESERT Underwater Framework](https://github.com/signetlabdei/DESERT_Underwater).

-------------------
About ns-2
------------------
ns has been maintained by the MASH Research Group (University of California, Berkeley, <http://www-mash.cs.berkeley.edu/ns/>)
the VINT project (a collaboration among USC/ISI, Xerox PARC, LBNL, and UCB, <http://www.isi.edu/nsnam/vint>) and the CONSER project <http://www.isi.edu/conser/>.

-----------------------
Documentation
-----------------------

A brief documentation is provided within this repository under `doc` folder, alternatively the ns manual can be found [here](http://www.isi.edu/nsnam/ns/doc).

