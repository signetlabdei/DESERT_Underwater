#
# Copyright (c) 1996-1997 Regents of the University of California.
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 3. All advertising materials mentioning features or use of this software
#    must display the following acknowledgement:
# 	This product includes software developed by the MASH Research
# 	Group at the University of California Berkeley.
# 4. Neither the name of the University nor of the Research Group may be
#    used to endorse or promote products derived from this software without
#    specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
# OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
# OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.
#
# @(#) $Header: /cvsroot/nsnam/ns-2/tcl/lib/ns-queue.tcl,v 1.28 2005/03/21 18:51:30 haldar Exp $
#

#
# This file contains auxillary support for CBQ and CBQ links, and
# some embryonic stuff for Queue Monitors. -KF
#

# Also contains some support for queue tracing and 
# procs for some queues like FQ and RED/PD
#



#
# QueueMonitor
#

QueueMonitor instproc reset {} {
	$self instvar size_ pkts_
	$self instvar parrivals_ barrivals_
	$self instvar pdepartures_ bdepartures_
	$self instvar pdrops_ bdrops_

	# don't reset size_ and pkts_ here
	# because they are not cumulative measurements
	# the way the following values are
	set parrivals_ 0
	set barrivals_ 0
	set pdepartures_ 0
	set bdepartures_ 0
	set pdrops_ 0
	set bdrops_ 0

	set bint [$self get-bytes-integrator]
	if { $bint != "" } {
		$bint reset
	}

	set pint [$self get-pkts-integrator]
	if { $pint != "" } {
		$pint reset
	}

	set samp [$self get-delay-samples]
	if { $samp != "" } {
		$samp reset
	}
}

QueueMonitor/ED instproc reset {} {
	$self next
	$self instvar epdrops_ ebdrops_ mon_epdrops_ mon_ebdrops_
	set epdrops_ 0
	set ebdrops_ 0
	set mon_epdrops_ 0
	set mon_ebdrops_ 0
}

# Class AckReconsClass -superclass Agent

# AckReconsControllerClass instproc demux { src dst } {
# 	$self instvar reconslist_ queue_
# 	set addr $src:$dst
# 	if { ![info exists reconslist_($addr)] } {
# 		set recons [new Agent/AckReconsClass $src $dst]
# 		$recons target $queue_
# 		set reconslist_($addr) $recons
# 	}
# 	# return an ack reconstructor object
# 	return $reconslist_($addr)
# }

# Calculate number and spacing of acks to be sent

# deltaAckThresh_ = threshold after which reconstructor kicks in
# ackInterArr_ = estimate of arrival rate of acks ("counting process")
# ackSpacing_ = duration in time between acks sent by reconstructor
# delack_ = generate an ack at least every delack_ acks at reconstructor

# Agent/AckReconsClass instproc spacing { ack } {
# 	$self instvar ackInterArr_ ackSpacing_ delack_ \
# 			lastAck_ lastRealAck_ lastRealTime_ adaptive_ size_
# 	global ns
# 	
# 	set deltaTime [expr [$ns now] - $lastRealTime_]
# 	set deltaAck [expr $ack - $lastAck_]
# 	if {$adaptive_} {
# 		set bw [expr $deltaAck*$size_/$deltaTime]
# 		set ackSpacing_ $ackInterArr_
# 		if { $deltaAck > 0 } {
# #			set ackSpacing_ [expr $ackInterArr_*$delack_/$deltaAck]
# 		}
# 	} else {
# 		set deltaT [expr $deltaTime / ($deltaAck/$delack_ +1)]
# 		set ackSpacing_ $deltaT
# 	}
# }

# Estimate rate at which acks are arriving
# Agent/AckReconsClass instproc ackbw {ack time} {
# 	$self instvar ackInterArr_ lastRealTime_ lastRealAck_ alpha_
# 
# 	set sample [expr $time - $lastRealTime_]
# 	# EWMA
# 	set ackInterArr_ [expr $alpha_*$sample + (1-$alpha_)*$ackInterArr_]
# }



#############################################################
# Stuff below has been added to enable queue specific tracing
#
#Blame me if anything is broken below - ratul
##########################################################

#
# attach-nam-traces: Only conventional trace objects are understood by nam currently. 
# do not attach fancy trace objects here. nam will crash in this case.
#
Queue instproc attach-nam-traces {src dst file} {
    
	#valid only if the default trace type in attach-traces is Drop, Enque, Deque.
	#see comment above.
	#this function should be different for different queue when needed.
	
	$self attach-traces $src $dst $file "nam"
}

#
# Dummy function for all the queues that don't implement attach-traces
#
Queue instproc attach-traces {src dst file {op ""}} {
	#Do nothing here
}

