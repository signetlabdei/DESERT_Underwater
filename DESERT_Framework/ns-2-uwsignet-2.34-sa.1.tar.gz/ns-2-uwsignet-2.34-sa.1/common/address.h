#ifndef NS_DUMMY_ADDRESS_H
#define NS_DUMMY_ADDRESS_H
class Address {
public:
    static Address& instance() { static Address a; return a; }
    int str2addr(const char*) { return 0; }
    char* print_nodeaddr(int) { return (char*)"0"; }
    char* print_portaddr(int) { return (char*)"0"; }
    int get_nodeaddr(int) { return 0; }
    int levels_;
    int hier_addr(int, int) { return 0; }
};
#endif
