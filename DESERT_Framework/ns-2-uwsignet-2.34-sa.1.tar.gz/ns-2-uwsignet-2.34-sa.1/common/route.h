#ifndef NS_DUMMY_ROUTE_H
#define NS_DUMMY_ROUTE_H
class RouteLogic {
public:
    int lookup_flat(...) { return 0; }
    void lookup_hier(...) {}
    static void ns_strtok(char*, int*) {}
    int elements_in_level(int*, int) { return 0; }
};
#endif
