#ifndef NS_DUMMY_ADDR_PARAMS_H
#define NS_DUMMY_ADDR_PARAMS_H
class AddrParams {};
class AddrParamsClass {
public:
    static AddrParamsClass& instance() { static AddrParamsClass a; return a; }
    int hlevel() { return 1; }
};
#endif
