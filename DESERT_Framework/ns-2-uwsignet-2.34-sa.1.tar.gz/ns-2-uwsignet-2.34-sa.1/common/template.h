#ifndef NS_DUMMY_TEMPLATE_H
#define NS_DUMMY_TEMPLATE_H
template<class T> class Template {};
#endif
