#ifndef NS_DUMMY_RTMODULE_H
#define NS_DUMMY_RTMODULE_H
class RtModule {};

class NsObject;
#include "object.h"
class RoutingModule : public TclObject {
public:
    RoutingModule* next_rtm_;
    void route_notify(RoutingModule*) {}
    void unreg_route_notify(RoutingModule*) {}
    void add_route(char*, NsObject*) {}
    void delete_route(char*, NsObject*) {}
    void set_table_size(int) {}
    void set_table_size(int, int) {}
};
#endif
